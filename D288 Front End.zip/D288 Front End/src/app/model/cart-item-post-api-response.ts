export class CartItemPostApiResponse {

  constructor(
    public _links: {
      self: {
        href: string
      }
    }
  ) {
  }
}
