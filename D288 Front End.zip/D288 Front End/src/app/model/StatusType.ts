export enum StatusType {
  pending = 'pending',
  ordered = 'ordered',
  cancelled = 'cancelled'
}
