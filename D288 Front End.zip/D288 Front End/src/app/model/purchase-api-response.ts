export class PurchaseApiResponse {

  constructor(
    public orderTrackingNumber: string
  ) {
  }
}
