package com.wgu.d288.services;


public interface CheckoutSrvc {
    PurchaseResponse placeOrder(Purchase purchase);
}
