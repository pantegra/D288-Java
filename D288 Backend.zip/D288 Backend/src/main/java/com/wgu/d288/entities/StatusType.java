package com.wgu.d288.entities;

public enum StatusType {
    pending, ordered, cancelled
}
