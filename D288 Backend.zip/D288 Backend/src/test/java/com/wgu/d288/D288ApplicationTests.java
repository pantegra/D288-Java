package com.wgu.d288;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D288ApplicationTests {

	@Test
	void contextLoads() {
	}

}
